var perro1={
	title:"Perro1",
	descripcion:"<p>Parrafo1</p>"
}

var perro2={
	title:"Perro2",
	descripcion:"<p>Parrafo2</p>"
}

var perro3={
	title:"Perro3",
	descripcion:"<p>Parrafo3</p>"
}

var perro4={
	title:"Perro4",
	descripcion:"<p>Parrafo4</p>"
}

var listaPerros=[perro1,perro2,perro3,perro4];