/*console.log("Bienvenido al mundo de JS");
console.log("hola")
console.log("bienvenido")
console.log("nuevo contenido");*/

// variable 

var dato1;
var dato2;
var dato3;
var dato4;



dato1="y el dijo :'hola' ";
dato2="999999999";
dato3=324;

var num1;
var num2;
var num3;
var resl1;
var resl2;
num1=10;
num2=15;
num3=30;
resl1=num1+num2+num3;
resl2=resl1/2;
console.log("la suma de 3 num divida entre 2 es igual a: ")
console.log(resl2);

var nombre="juan carlos";
var apellidoP="Ramos"
var apellidoM="Torriccelli";

var nombrecompleto=nombre+" "+apellidoP+" "+apellidoM;
/* 
juan carlos Ramos Torriccelli
*/

var _num1="10";
var _num2="16";
var rsl;
var nuevo_n1=parseInt(_num1);
var nuevo_n2=parseInt(_num2)
rsl=nuevo_n1+nuevo_n2;

"1020"
