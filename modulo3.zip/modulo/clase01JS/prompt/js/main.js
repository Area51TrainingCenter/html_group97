//ventana de alerta
//alert("Welcome!!");
//prompt()
/*var n1=prompt("Ingresa el 1er numero");
var n2=prompt("Ingresa el 2do numero");

var num1=parseInt(n1);
var num2=parseInt(n2);
console.log(num1+num2);
*/
var num_mayor=Math.max(10,22,34,9997);
var num_menor=Math.min(-0.5,22,34,9997);
console.log(num_mayor);
console.log(num_menor);

Math.pow(2,5);
Math.sqrt(169);
var aleatorio=Math.random()*1000;
console.log(Math.round(aleatorio));
